block_availability(){
available_blocks=(`df|awk '{print $4}'|sed '1d'`)
total=0

for v in ${available_blocks[@]}
do
	total=`expr $v + $total`
done
echo "Sum of Available block size:$total"
}

LogSize(){

A=(`ls -l *.log|awk '{print $5}'`)
t=0
for v in ${A[@]}
do
	t=`expr $v + $t`
done
echo "Sum of log file size:$t"
}
