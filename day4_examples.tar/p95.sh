BEGIN{
if(100>50){
	print "True"
}else{
	print "False"
}
for(i=0;i<5;i++){
	print i
}
i=0
while(i<5){
	print i
	i++
}
}
