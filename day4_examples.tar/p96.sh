echo "This is shell script - PID:$$"
echo "File name:$0"
echo "python3 will start in 5 secs"
sleep 5
python3<<abc
import os,sys
print("this is python programming")
print("python PID:{}".format(os.getpid()))
print("Version:{}".format(sys.version))
abc
echo 
echo "Exit from $0 script file"
