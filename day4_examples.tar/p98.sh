
S=("100GB" "GB120" "g500" "120Gb" "200")

for v in ${S[@]}
do
	echo "$v"|sed 's/[A-Za-z]//g'
done
