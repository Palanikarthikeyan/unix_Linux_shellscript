
read -p "Enter a daemon name:" var

systemctl is-active $var >/dev/null
if [ $? -eq 0 ];then
	echo "Yes - daemon $var is active"
else
	echo "Sorry daemon $var is not active"
fi

