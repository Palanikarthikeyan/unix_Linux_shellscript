
S=("100GB" "GB120" "g500" "120Gb" "200")
t=0
for v in ${S[@]}
do
	v=`echo "$v"|sed 's/[A-Za-z]//g'`
	t=`expr $v + $t`
done
echo "Sum of Size:$t GB"
