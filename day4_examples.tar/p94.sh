echo "This is shell script"
echo # empty line

awk 'BEGIN{
print "List of sales emp details:-"
print "---------------------------"
FS=","
OFS="\t"
}
/sales/{print NR,$2,$NF,$NF*0.12}
END{
print "--------------------------"
print "   Thank you !!!  "
print "--------------------------"
}' emp.csv
echo # empty line
echo "this is shell script section"
