BEGIN{
print "List of sales emp details:-"
print "---------------------------"
FS=","
OFS="\t"
}
/sales/{print NR,$2,$NF,$NF*0.12}
END{
print "--------------------------"
print "   Thank you !!!  "
print "--------------------------"
}
