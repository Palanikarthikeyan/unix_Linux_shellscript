
read -p "Enter N value:" n
read -p "Enter M value:" m

t=`echo $n $m|awk '{print $1+$2}'`
m=`echo $n $m|awk '{print $1*$2}'`

echo -e "total:$t \t multiple:$m"


echo 15.32:0.05|awk -F: '{print $1+$2}'
