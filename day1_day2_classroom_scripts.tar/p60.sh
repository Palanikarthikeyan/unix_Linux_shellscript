if [ $# -eq 0 ]
then
	echo "Usage:Empty argument"
	exit
fi
if [ $# -gt 1 ]
then
	echo "Usage:Commandline args accept single inputfile"
	exit
fi

if [ -e $1 ]
then
	echo "File:$1 is exists"
else
	echo "File:$1 is not exists"
fi
