if [ `whoami` == "root" ]
then
	read -p "enter a user name:" user_name
	useradd $user_name
	if [ $? -eq 0 ]
	then
		echo "user $user_name is created"
	else
		echo "Sorry $user_name creation is failed"
	fi
else
	echo "Sorry your not root user"
fi

