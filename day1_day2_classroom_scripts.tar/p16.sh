read -p "Enter a port number:" port

if [ $port -gt 500 ]
then
	echo "Application port number is:$port"
fi

