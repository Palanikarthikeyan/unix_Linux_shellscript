read -p "Enter a directory name:" dname

mkdir $dname

if [ $? -eq 0 ]
then
	echo "Directory $dname is created"
	ls -ld $dname
else
	echo "Sorry directory $dname creation is failed"
fi

