echo "Today:`date +%D`" # date is a system command
# %+D is date format - MM/DD/YYYY style
# to get more format refer
# man date
echo # empty line
echo "display current process"
echo "mounted filesystem"
df -Th
echo "End of the script"
