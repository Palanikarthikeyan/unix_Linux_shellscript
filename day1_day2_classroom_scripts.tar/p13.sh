echo "Enter a file name:"
read fname
echo "Enter $fname size:"
read fsize
echo "Enter $fname permission:"
read perm

echo "
---------------------------
File name:$fname
File Size:$fsize
File Permission:$perm
----------------------------"
