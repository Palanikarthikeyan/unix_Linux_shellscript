dept="sales"

case $dept in	
prod) echo "Matched-1" ;;
QA)  echo "Matched-2" ;;
sales) echo "Matched-3" ;;
CRM) echo "Matched-4" ;;
*) echo "Not-Matched"
esac
