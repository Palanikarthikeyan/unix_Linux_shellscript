
echo "List of files:-"
echo "------------------"

for v in `ls p*`
do
	echo "file name:$v"
	sleep 1
done
