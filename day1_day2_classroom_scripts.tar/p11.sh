
echo "Enter a emp name:"
read ename
echo "Enter emp ID:"
read eid
echo "Enter $ename working dept:"
read edept
echo "About $ename details:-
------------------------------
name:$ename
eid:$eid
emp working dept is:$edept
------------------------------"
