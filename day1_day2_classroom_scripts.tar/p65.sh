servers=(unix linux winx minix aix)

echo ${servers[0]}
echo ${servers[1]}
echo ${servers[2]}
echo
echo ${servers[@]}
echo ${servers[*]}
echo 
echo "Total no.of items:${#servers[@]}"
