select v in unix linux aix minix winx
do
	echo "Selected server name:$v"
	break
done
