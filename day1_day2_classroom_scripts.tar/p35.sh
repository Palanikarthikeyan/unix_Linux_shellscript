while :
do
	read -p "Enter a username:" name
	if [ $name == "admin" -o $name == "ADMIN" ]
	then
		echo "Matched"
		break
	else
		echo "Not-Matched"
	fi
done
