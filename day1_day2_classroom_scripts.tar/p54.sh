
while read var
do
echo "$var"
done<emp.csv >e1.csv

# reading data from <oneFILE> -- to script -- create/write data to anotherFILE
#
# cp emp.csv e1.csv
# -----------------
# cp emp.csv /home/user/project/e1.csv
# -----------------------------------
