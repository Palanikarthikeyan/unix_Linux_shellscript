
for v in file1 file2 file3 file4 file5
do
	if [ $v == "file3" ]
	then
		#break
		continue
	else
		echo "$v"
	fi
done
