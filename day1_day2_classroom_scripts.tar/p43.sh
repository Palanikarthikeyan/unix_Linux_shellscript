echo "List of log files:-"
echo "-------------------------"
i=0
for v in `ls *.log`
do
	echo "$((++i)). $v"
done
echo "--------------------------------
	Total no.of log files:$i
---------------------------------"
