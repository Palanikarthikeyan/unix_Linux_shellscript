
c=0
while read var
do
	if [ $c -gt 5 -a $c -lt 10 ]
	then
		echo "$var"
	fi
	c=`expr $c + 1`
done<emp.csv >e2.csv
