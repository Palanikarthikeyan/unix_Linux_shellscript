echo $@
echo
echo $*
echo 
for v in "$@"
do
	echo "->$v"
done
echo 
for v in "$*"
do
	echo "===>$v"
done
