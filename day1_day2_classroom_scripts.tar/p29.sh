dept="sales"
if [ $dept == "prod" ]
then
	echo "Matched-1"
elif [ $dept == "QA" ]
then
	echo "Matched-2"
elif [ $dept == "sales" ]
then
	echo "Matched-3"
elif [ $dept == "CRM" ]
then
	echo "Matched-4"
else
	echo "Not-Matched"
fi
