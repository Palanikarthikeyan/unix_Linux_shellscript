if [ $# -eq 0 ]
then
	echo "Usage: Commandline args is empty"
	echo "$0 <number1> <number2>"
	exit
fi

if [ $# -ne 2 ]
then
	echo "Usage:Commandline args accept any two numbers"
	echo "$0 <number1> <number2>"
	exit
fi

echo "Total:`expr $1 + $2`"
