
c=0
while [ $c -lt 3 ]
do
	ps >>process.log
	date >>d1.log
	pwd >>p1.log
	c=`expr $c + 1`
done 
