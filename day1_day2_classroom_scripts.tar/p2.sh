echo "This is sample shell script"
echo "Today:`date +%D`"
echo "My working kernel name is:`uname`"
sleep 5
echo "Thank you!!!"
