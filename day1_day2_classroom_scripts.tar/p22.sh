read -p "Enter a appname:" app

if [ $app == "flask" ]
then
	port=5000
else
	port=8000
fi

echo -e "App name:$app\t Running port number:$port"
