echo "My hostname is:`hostname`"
echo "Today:`date +%D`"
echo "My Login name is:`whoami`"
echo "Current working directory:`pwd`"
