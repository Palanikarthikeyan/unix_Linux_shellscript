read -p "Enter a file name:" fname
read -p "Enter $fname size:" fsize
read -p "Enter $fname permission:" perm

echo "
---------------------------
File name:$fname
File Size:$fsize
File Permission:$perm
----------------------------"
