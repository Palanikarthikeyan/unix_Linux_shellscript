# using commandline args - expr operation
# 
if [ $# -eq 0 ]
then
	echo "Usage:Empty argument"
	exit
fi

if [ $# -gt 2 ]
then
	echo "Usage:command args required 2 args"
	exit
fi
echo "Total value:`expr $1 + $2`"
