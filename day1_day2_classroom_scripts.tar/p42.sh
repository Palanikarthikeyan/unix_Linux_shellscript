select v in unix linux aix minix winx quit
do
	case $v in
	unix) echo "Selected server name is:$v"
	      ;;
	linux) echo "Working kernel name and version:`uname -rs`"
		;;
	aix) echo "Current process:-"
	     ps 
	     ;;
	minix) echo "Today:`date +%D`" ;;
	winx) echo "Current working directory:`pwd`" 
		;;
	quit)  echo "Thank you"
	       break
	       ;;
	*)  echo "Invalid choice"
	esac
done
