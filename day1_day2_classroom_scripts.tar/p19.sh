read -p "Enter a search pattern:" key

grep $key emp.csv

if [ $? -ne 0 ]
then
	echo "Usage:Sorry pattern $key is not exists from emp.csv file"
fi

