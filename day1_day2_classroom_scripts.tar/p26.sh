read -p "enter a shell name:" var

if [ $var == "bash" -o $var == "ksh" ]
then
	fname=".profile"
else
	echo "Sorry input shell $var is not matched"
	exit
fi
echo -e "Shell name:$var\t Shell profile:$fname"
