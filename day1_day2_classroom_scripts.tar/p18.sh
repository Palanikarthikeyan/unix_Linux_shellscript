if [ $UID -eq 0 ]
then
	echo "Install a following packages"
	# yum -y install gcc
else
	echo "Sorry your not root user"
fi
echo # empty line

if [ `whoami` == "root" ]
then
	echo "Start a webserver"
	# systemctl start apache2
else
	echo "Sorry your not a root user"
fi
