echo ${1} ${2} ${3} 
echo $@
echo
echo $*
echo 
echo "Total no.of args:$#"
