echo "My hostname is:`hostname`
Today:`date +%D`
My Login name is:`whoami`
Current working directory:`pwd`"
