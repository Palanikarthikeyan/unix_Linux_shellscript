echo "My hostname is:`hostname`
Today:`date +%D`
My Login name is:`whoami`
Current working directory:`pwd`"

echo "---------------------------"

echo -e "My Hostname:`hostname`\nToday:`date +%D`\tLogin:`whoami`\nWorking directory:`pwd`"
