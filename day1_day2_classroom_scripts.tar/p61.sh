
if [ $# -ne 1 ]
then
	echo "Usage:Commandline args error"
	exit
fi

fname=$1 # we can initialize commandline arg input to
	 # user defined variable

if [ -e $fname ]
then
	echo "Yes file:$fname is exists"
	file $fname
else
	echo "Sorry file:$fname is not exists"
fi
