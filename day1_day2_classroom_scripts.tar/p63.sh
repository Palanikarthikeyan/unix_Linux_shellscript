echo "Working script file name:$0"
echo "Total no.of args:$#"
echo "Running script PID:$$"
echo "Exit from $0 script"
