c=0

for v in 10 20 30 40 50
do
	c=`expr $c + $v`
done
echo "Sum of digits:$c"
