read -p "Enter a file name:" fname

if [ -e $fname ]
then
	if [ -f $fname ]
	then
		echo "Yes input file is $fname is a reg.file"
		ls -l $fname
	elif [ -d $fname ]
	then
		echo "Yes input file is $fname is a dir file"
		ls -ld $fname
	else
		file $fname
	fi

else
	echo "Sorry file $fname is not exists"
	exit # exit from script
fi
