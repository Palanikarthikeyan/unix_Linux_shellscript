i=0

while [ $i -lt 5 ]
do
	read -p "Enter a username:" name
	if [ $name == "admin" -o $name == "ADMIN" ]
	then
		echo "Matched"
	else
		echo "Not-Matched"
	fi
	i=`expr $i + 1`
done
echo 
echo "next section of code"
