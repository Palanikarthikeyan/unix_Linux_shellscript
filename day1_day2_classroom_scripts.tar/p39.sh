echo "List of dir files:-"
echo "-------------------------------"

for v in `ls`
do
	if [ -d $v ]
	then
		echo "$v"
		ls -ld $v
	fi
done
