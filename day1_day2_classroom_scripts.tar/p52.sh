
c=0
while read var
do
	echo "$((++c)) $var"
done<emp.csv
