i=15
while [ $i -lt 5 ] # 15 < 5 ->False
do
	echo "Hello"
done
echo "until demo"
i=15
until [ $i -lt 5 ] # 15<5 ->False - code block will execute
do
	echo "i value is:$i"
	i=`expr $i - 1`
done
	
