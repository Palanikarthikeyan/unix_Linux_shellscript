c=0
while [ $c -lt 3 ]
do
	ps
	echo
	date
	echo
	pwd
	echo "----------------------"
	c=`expr $c + 1`
done >r1.log
