read -p "Enter a dept:" dept

case $dept in
sales)  echo "selected dept is:$dept"
	;;
prod|PROD) echo "production dept" ;;
q|Q) echo "q-quality" ;;
56)  echo "dept code is:56" ;;
1.45) echo "value is:1.45" 
       ;;
*)	echo "invalid pattern"
esac

