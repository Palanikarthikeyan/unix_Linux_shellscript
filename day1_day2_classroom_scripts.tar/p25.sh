echo "ONE"
echo "TWO"
echo "THREE"
exit # exit from script
echo "TEST-1"
echo "TEST-2"
