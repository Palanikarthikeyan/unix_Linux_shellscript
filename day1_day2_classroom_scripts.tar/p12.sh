#d1="/dev/sda1"
#p1="150GB"
#d2="/dev/sda2"
#p2="250GB"

echo "Enter a partition name:"
read d1
echo "Enter $d1 partition size:"
read p1
echo "Enter another partition name:"
read d2
echo "Enter $d2 partition size:"
read p2

echo -e "Partition name:$d1\tSize:$p1\nPartition name:$d2\tSize:$p2" 

