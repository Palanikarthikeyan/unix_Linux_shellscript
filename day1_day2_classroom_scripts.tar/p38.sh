for v in `date`
do
	echo "$v"
done
