for v in server1 server2 server3 server4 server5 server6 server7
do
	if ! [ $v == "server3" -o $v == "server4" -o $v == "server6" ]
	then
		echo "$v"
	fi
done
