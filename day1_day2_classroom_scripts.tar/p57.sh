echo $1 $2 $3 $10 $11 $12 $13
echo
echo ${1} ${2} ${3} 
echo "10th arg:${10}"
echo "11th arg:${11}"
echo "12th arg:${12}"
