for v in p1.sh p2.sh 10 2.44 10.20.30.50 "Red Hat 7.9" Oracle Linux 6.5
do
	echo "v value is:$v"
done
