echo "Today:`date +%D`"
# date is a command - internal command
# date +%D - is a format
# MM/DD/YYYY format
# to get more format refer man date 

echo "Today:`date +%D`"
<<EOF
date is a command - this is internal command
date +%D is a format
MM/DD/YYYY format
to get more format refer man date
EOF
echo "End of the script"

