i=0
while [ $i -lt 5 ]
do
	echo "i value is:$i"
	date
	sleep 2
	i=`expr $i + 1`
done
