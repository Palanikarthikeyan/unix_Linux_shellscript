d1="/dev/sda1"
p1="150GB"
d2="/dev/sda2"
p2="250GB"

echo "
Partition name:$d1 	Size:$p1
------------------------------------
Partition name:$d2 	Size:$p2
------------------------------------"

