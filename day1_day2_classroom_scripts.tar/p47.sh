
for v in 1 2 3
do
	date
	sleep 2
	ps
	sleep 1
	echo -e "Login Shell:$SHELL\t Login name:`whoami`"
	echo # empty line
done
