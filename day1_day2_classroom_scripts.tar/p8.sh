pkg="httpd"
echo "package name is:$pkg"
echo "install a $pkg"
# yum install $pkg
# apt-get install $pkg

