
for v in `ls *.log`
do
	while read var
	do
			echo "$var"
	done<$v >$v.txt
done  
