servers=(unix linux winx minix aix)


for v in ${servers[@]}
do
	echo "$v"
done
