
fx(){
	local counter=15
	return $counter
}
fx
n=$?
echo "Counter:$n"
