

if [ `cut -d, -f 3 emp.csv |sort|uniq -i|wc -l` -gt 10 ];then
	echo "There are more than 10 depts"
else
	echo "Total no.of dept is less than 10"
	for v in `cut -d, -f 3 emp.csv|sort|uniq -i`
	do
		echo "$v"
	done
fi 
