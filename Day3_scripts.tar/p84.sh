read -p "Enter a directory:" dname

if [ -d $dname ]
then
	echo "Directory $dname is already exists"
	ls -ld $dname	
else
	mkdir $dname 2>/dev/null
	if [ $? -eq 0 ]
	then
		echo "Directory $dname is created successfully"
		ls -ld $dname
	else
		echo "Directory creation is failed"
	fi
fi
