echo "This is $0 script file"
echo "$1 $2 $3" # this is commandline args
echo "$@"       # this is commandline args
echo "$#"       # total no.of commandline args
f1(){
	echo "This is $FUNCNAME Block"
	echo "$1 $2 $3"
	echo "$@"
	echo "$#"
	echo "Exit from $FUNCNAME Block"
}
f2(){
	echo "This is $FUNCNAME block"
	echo $1 $2 $3
	echo "$@"
	echo "$#"
	echo "Exit from $FUNCNAME block"
}
f1 p1.sh p2.sh p3.sh p4.sh p5.sh # function call arguments
f2 10 20 30 40   # function call arguments
f1 # simple function call - there is no args
echo "Exit from $0 script"
