
fx(){
	local counter=15
	echo "From $FUNCNAME block - counter value is:$counter"
}
fx
echo "Counter:$counter"
