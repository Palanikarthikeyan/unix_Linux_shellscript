echo "This is $0 script"

f1(){
	echo "This is f1 block"
	for v in unix linux winx
	do
		echo "connected server:$v"
	done
	echo "exit from f1 block"
}
f2(){
	echo "Current process:-"
	ps 
	echo "exit from f2 block"
}
f1 # 1st call - simple function call
sleep 3
f2 # 2nd call - simple function call
sleep 2
f1 # calling again
echo "exit from $0 script"
