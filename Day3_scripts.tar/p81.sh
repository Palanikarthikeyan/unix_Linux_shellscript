
if [ "userA" == "userA" -a 505 -gt 500 -a "app-1" == "app-1" -a 100 -lt 150 ]
then
	echo "True"
else
	echo "False"
fi

if [ "userA" == "userA" -a 505 -gt 500 ] && [ "app-1" == "app-1" -a 100 -lt 150 ]
then
	echo "True"
else
	echo "False"
fi

if [[ "userA" == "userA" && 505 -gt 500 ]] && [[ "app-1" == "app-1" && 100 -lt 150 ]]
then
	echo "True"
else
	echo "False"
fi
