f1(){
	echo "A.$#"
}
f2(){
	echo "B.$#"
}
f1 $@ D1 D2 D3
f2 A B C
echo "C.$#"
