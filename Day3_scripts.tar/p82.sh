
if [ -e pp.log ]
then
	ls -l pp.log
else
	exit
fi

[ -e pp.log ] || exit
ls -l pp.log
# ...

