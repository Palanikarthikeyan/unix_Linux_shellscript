
fx(){
	local counter=15
	return $counter
}
fx
echo "Counter:$?"
