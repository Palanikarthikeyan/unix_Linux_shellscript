if [ $# -ne 1 ];then
	echo "Commandline arg error"
	echo "$0 <filename.csv>"
	exit
fi

while read var
do
	echo "$var"|grep -i sales|cut -d, -f2
	echo "$var"|grep -i sales|cut -d, -f4
	echo "$var"|grep -i sales|cut -d, -f5
done<$1
