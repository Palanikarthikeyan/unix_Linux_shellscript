List(){
	echo "List of log files:-"
	ls -l *.log
	echo "exit from List block"
}
process(){
	echo "Current process:-"
	ps
	echo "Exit from process block"
}
Today(){
	echo "Today:`date +%D`"
	echo "Hour:`date +%H`"
	echo "Exit from Today block"
}
Quit(){
	echo "Thank you"
	exit
}
while :
do
	echo "1. List of log files
	2. current process 
	3. Today
	4. Exit from menu list"
	read -p "Enter your choice:" choice
	case $choice in
	1) List ;;
	2) process ;;
	3) Today ;;
	4) Quit ;;
	*) echo "Invalid choice"
	esac
done
