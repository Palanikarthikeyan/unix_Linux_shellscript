echo "This is $0 script"

f1(){
	set -x
	echo "This is $FUNCNAME block"
	for v in unix linux winx
	do
		echo "connected server:$v"
	done
	echo "exit from $FUNCNAME block"
	set +x
}
f2(){
	echo "This is $FUNCNAME block"
	echo "Current process:-"
	ps 
	echo "exit from $FUNCNAME block"
}
f1 # 1st call - simple function call
sleep 3
f2 # 2nd call - simple function call
sleep 2
f1 # calling again
echo "exit from $0 script"
