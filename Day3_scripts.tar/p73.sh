port=8080 # this is script section

display(){
	echo "App port number is:$port"
	app="webserver" # by default all the function variables - global access 
}
echo "--> App name is:$app"
display
echo "App name is:$app"

