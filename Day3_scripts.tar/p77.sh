nametest(){
	read -p "Enter your name:" name
	if [ $name == "root" ]
	then
		return 0
	else
		return 1
	fi
}
nametest # simple functionCall
if [ $? -eq 0 ]
then
	echo "Login is success"
else
	echo "Login is failed"
fi
