port=5000
app=flask
user="admin"
display(){
	echo "System info"
	echo "-----------"
	uname -rs
	hostname
	whoami
	echo "exit from $FUNCNAME Block"
}
view(){
	echo "Current process:-"
	ps
	echo "exit from $FUNCNAME Block"
}
