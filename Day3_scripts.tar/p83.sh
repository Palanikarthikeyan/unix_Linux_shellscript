fname=`basename $0`
echo "file name:$fname"
