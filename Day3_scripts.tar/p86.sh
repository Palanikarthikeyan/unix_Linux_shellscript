read -p "Enter a file name:" fname
read -p "Enter a sep:" sep
read -p "Enter a field Value:" fv

A=(`cut -d"$sep" -f"$fv" $fname|sort`)

for v in ${A[@]}
do
	echo "->$v"
done
echo "Total no.of items:${#A[@]}"
