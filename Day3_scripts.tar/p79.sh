echo "This is $0 file"
source /home/node1/p78
echo "$port"
display
