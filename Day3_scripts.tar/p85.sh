
if [ $# -eq 0 ]
then
	echo "Usage: Commandline argument is empty"
	echo "$0 <filename>"
	exit
fi
if [ $# -gt 1 ]
then
	echo "Usage:Commandline argument allowed single file"
	echo "$0 <filename>"
	exit
fi

if [ "`basename $0`" == "$1" ]
then
	echo "Usage:Input file and script both are same"
	echo "$0 <filename>"
	exit
fi

if [ -e $1 ]
then
	echo "File:$1 is exists"
else
	echo "File:$1 is NOT exists"
fi
