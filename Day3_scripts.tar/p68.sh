display(){
	echo -e "Login:`whoami`\tLoginID:$UID"
	echo "Host name:`hostname`"
	echo "Kernel:`uname -rs`"
	echo "Exit from display block"
}
calc(){
	read -p "Enter N value:" n
	read -p "Enter M value:" m
	echo "Total value:`expr $n + $m`"
	echo "Exit from calc block"
}

echo "1. display your system info
2. test mathematical expression"
read -p "Enter your choice:" choice
case $choice in
1) display ;; 
2) calc ;;
*) echo "Invalid choice"
esac

